package rest.error;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class FacturaNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 43876691117560211L;

	
	public FacturaNotFoundException(Long id) {
		super("No se puede encontrar el cliente con la ID: " + id);
	}
	
	
}
