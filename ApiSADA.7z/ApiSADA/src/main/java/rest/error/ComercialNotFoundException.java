package rest.error;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class ComercialNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 43876691117560211L;

	
	public ComercialNotFoundException(Long id) {
		super("No se puede encontrar el comercial con la ID: " + id);
	}
	
	public ComercialNotFoundException(String dni) {
		super("No se puede encontrar el comercial con DNI: " + dni + "  o la contraseña es incorrecta");
	}
	
	
}
