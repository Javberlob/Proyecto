package rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CreateRutaDTO {
	
	private Long id_ruta;

}
