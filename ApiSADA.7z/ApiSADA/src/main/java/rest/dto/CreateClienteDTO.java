package rest.dto;

import lombok.Getter;
import lombok.Setter;


@Getter @Setter
public class CreateClienteDTO {
	
	private Long id_cliente;
	
	private String nombre;
	
	private String dni;

	private String telefono;
	
	private String direccion;
	
	private long ruta;

}
