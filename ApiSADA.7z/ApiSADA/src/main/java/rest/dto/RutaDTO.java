package rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RutaDTO {
	
	private Long id_ruta;

}
