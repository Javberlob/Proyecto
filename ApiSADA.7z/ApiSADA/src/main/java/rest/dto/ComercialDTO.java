package rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComercialDTO {
	
	private Long id_comercial;
	
	private String nombre;
	
	private String dni;

	private String telefono;


}
