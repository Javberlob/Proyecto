package rest.dto.converter;

import javax.annotation.PostConstruct;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import rest.dto.FacturaDTO;
import rest.modelo.Factura;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class FacturaDTOConverter {
	
	private final ModelMapper modelMapper;
	
	
	@PostConstruct
	public void init() {
		modelMapper.addMappings(new PropertyMap<Factura, FacturaDTO>() {

			@Override
			protected void configure() {
				map().setComercial(source.getComercial().getId_comercial());
				map().setCliente(source.getCliente().getId_cliente());
				
			}
		});
	}
	
	public FacturaDTO convertToDto(Factura factura) {
		return modelMapper.map(factura, FacturaDTO.class);
		
	}

}
