package rest.dto.converter;

import javax.annotation.PostConstruct;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import rest.dto.ClienteDTO;
import rest.modelo.Cliente;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class ClienteDTOConverter {
	
	private final ModelMapper modelMapper;
	
	
	@PostConstruct
	public void init() {
		modelMapper.addMappings(new PropertyMap<Cliente, ClienteDTO>() {

			@Override
			protected void configure() {
				map().setRuta(source.getRuta().getId_ruta());
			}
		});
	}
	
	public ClienteDTO convertToDto(Cliente cliente) {
		return modelMapper.map(cliente, ClienteDTO.class);
		
	}

}
