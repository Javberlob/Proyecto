package rest.dto.converter;

import javax.annotation.PostConstruct;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import rest.dto.PedidoDTO;
import rest.modelo.Pedido;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class PedidoDTOConverter {
	
	private final ModelMapper modelMapper;
	
	
	@PostConstruct
	public void init() {
		modelMapper.addMappings(new PropertyMap<Pedido, PedidoDTO>() {

			@Override
			protected void configure() {
				map().setFactura(source.getFactura().getId_factura());
				map().setProducto(source.getProducto().getId_producto());
				
			}
		});
	}
	
	public PedidoDTO convertToDto(Pedido pedido) {
		return modelMapper.map(pedido, PedidoDTO.class);
		
	}

}
