package rest.dto;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class PedidoDTO {
	
	private Long id_Pedido;
	
	private long factura;
	
	private long producto;
	
	private int cantidad;
	
	private float precio;

}
