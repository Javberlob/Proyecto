package rest.dto;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ClienteDTO {
	
	private Long id_cliente;
	
	private String nombre;
	
	private String dni;

	private String telefono;
	
	private String direccion;
	
	private int descuento;
	
	private long ruta;

}
