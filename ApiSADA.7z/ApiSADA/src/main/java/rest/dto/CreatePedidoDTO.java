package rest.dto;


import lombok.Getter;
import lombok.Setter;


@Getter @Setter
public class CreatePedidoDTO {
	
	private Long id_factura;
	
	private long factura;
	
	private long producto;

	private int cantidad;

	private float precio;
}
