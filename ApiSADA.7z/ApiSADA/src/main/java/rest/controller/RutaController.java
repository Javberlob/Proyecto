package rest.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Example;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import rest.dto.RutaDTO;
import rest.dto.ClienteDTO;
import rest.dto.CreateRutaDTO;
import rest.dto.converter.ClienteDTOConverter;
import rest.dto.converter.RutaDTOConverter;
import rest.error.RutaNotFoundException;
import rest.modelo.Cliente;
import rest.modelo.ClienteRepositorio;
import rest.modelo.Ruta;
import rest.modelo.RutaRepositorio;


import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class RutaController {

	private final RutaRepositorio rutaRepositorio;
	private final ClienteRepositorio clienteRepositorio;
	
	private final RutaDTOConverter rutaDTOConverter;
	private final ClienteDTOConverter clienteDTOConverter;

	/**
	 * Obtenemos todos los rutas
	 * 
	 * @return 404 si no hay rutas, 200 y lista de rutas si hay uno o más
	 */
	@GetMapping("/ruta")
	public ResponseEntity<?> obtenerTodos() {
		List<Ruta> result = rutaRepositorio.findAll();

		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		} else {

			List<RutaDTO> dtoList = result.stream().map(rutaDTOConverter::convertToDto)
					.collect(Collectors.toList());

			return ResponseEntity.ok(dtoList);
		}

	}
	
	/**
	 * Obtenemos todos los rutas
	 * 
	 * @return 404 si no hay rutas, 200 y lista de rutas si hay uno o más
	 */
	@GetMapping("/ruta/{id}/clientes")
	public ResponseEntity<?> obtenerTodos(@PathVariable long id) {
		Cliente c= new Cliente();
		Ruta r=new Ruta();
		r.setId_ruta(id);
		c.setRuta(r);
		Example<Cliente> example = Example.of(c);
		List<Cliente> result = clienteRepositorio.findAll(example);

		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		} else {

			List<ClienteDTO> dtoList = result.stream().map(clienteDTOConverter::convertToDto)
					.collect(Collectors.toList());

			return ResponseEntity.ok(dtoList);
		}

	}

	/**
	 * Obtenemos un ruta en base a su ID
	 * 
	 * @param id
	 * @return 404 si no encuentra el ruta, 200 y el ruta si lo encuentra
	 */
	@GetMapping("/ruta/{id}")
	public RutaDTO obtenerUno(@PathVariable Long id) {
		RutaDTO rutaDTO = rutaDTOConverter.convertToDto(rutaRepositorio.findById(id)
				.orElseThrow(() -> new RutaNotFoundException(id)));
		return rutaDTO;
			

			
	}

	/**
	 * Insertamos un nuevo ruta
	 * 
	 * @param nuevo
	 * @return 201 y el ruta insertado
	 */
	@PostMapping("/ruta")
	public ResponseEntity<?> nuevoRuta(@RequestBody CreateRutaDTO nuevo) {
		
		Ruta nuevoRuta = new Ruta();
		
		return ResponseEntity.status(HttpStatus.CREATED).body(rutaRepositorio.save(nuevoRuta));
	}

	/**
	 * 
	 * @param editar
	 * @param id
	 * @return 200 Ok si la edición tiene éxito, 404 si no se encuentra el ruta
	 */
	@PutMapping("/ruta/{id}")
	public Ruta editarRuta(@RequestBody Ruta editar, @PathVariable Long id) {

		return rutaRepositorio.findById(id).map(p -> {
			return rutaRepositorio.save(p);
		}).orElseThrow(() -> new RutaNotFoundException(id));
	}

	/**
	 * Borra un ruta del catálogo en base a su id
	 * 
	 * @param id
	 * @return Código 204 sin contenido
	 */
	@DeleteMapping("/ruta/{id}")
	public ResponseEntity<?> borrarRuta(@PathVariable Long id) {
		Ruta ruta = rutaRepositorio.findById(id)
				.orElseThrow(() -> new RutaNotFoundException(id));
		
		rutaRepositorio.delete(ruta);
		return ResponseEntity.noContent().build();
	}
	

}
