package rest.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import rest.dto.ClienteDTO;
import rest.dto.CreateClienteDTO;
import rest.dto.converter.ClienteDTOConverter;
import rest.error.ClienteNotFoundException;
import rest.modelo.Cliente;
import rest.modelo.ClienteRepositorio;
import rest.modelo.Ruta;
import rest.modelo.RutaRepositorio;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class ClienteController {

	private final ClienteRepositorio clienteRepositorio;
	private final RutaRepositorio rutaRepositorio;
	
	private final ClienteDTOConverter clienteDTOConverter;

	/**
	 * Obtenemos todos los clientes
	 * 
	 * @return 404 si no hay clientes, 200 y lista de clientes si hay uno o más
	 */
	@GetMapping("/cliente")
	public ResponseEntity<?> obtenerTodos() {
		List<Cliente> result = clienteRepositorio.findAll();

		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		} else {

			List<ClienteDTO> dtoList = result.stream().map(clienteDTOConverter::convertToDto)
					.collect(Collectors.toList());

			return ResponseEntity.ok(dtoList);
		}

	}

	/**
	 * Obtenemos un cliente en base a su ID
	 * 
	 * @param id
	 * @return 404 si no encuentra el cliente, 200 y el cliente si lo encuentra
	 */
	@GetMapping("/cliente/{id}")
	public Cliente obtenerUno(@PathVariable Long id) {
		return clienteRepositorio.findById(id)
				.orElseThrow(() -> new ClienteNotFoundException(id));
	}

	/**
	 * Insertamos un nuevo cliente
	 * 
	 * @param nuevo
	 * @return 201 y el cliente insertado
	 */
	@PostMapping("/cliente")
	public ResponseEntity<?> nuevoCliente(@RequestBody CreateClienteDTO nuevo) {
		
		Cliente nuevoCliente = new Cliente();
		nuevoCliente.setNombre(nuevo.getNombre());
		nuevoCliente.setDni(nuevo.getDni());
		nuevoCliente.setTelefono(nuevo.getTelefono());
		nuevoCliente.setDireccion(nuevo.getDireccion());
		nuevoCliente.setDescuento(0);
		nuevoCliente.setRuta(rutaRepositorio.findById(nuevo.getRuta()).orElse(null));
		return ResponseEntity.status(HttpStatus.CREATED).body(clienteRepositorio.save(nuevoCliente));
	}

	/**
	 * 
	 * @param editar
	 * @param id
	 * @return 200 Ok si la edición tiene éxito, 404 si no se encuentra el cliente
	 */
	@PutMapping("/cliente/{id}")
	public Cliente editarCliente(@RequestBody ClienteDTO editar, @PathVariable Long id) {

		return clienteRepositorio.findById(id).map(c -> {
			c.setNombre(editar.getNombre());
			c.setDni(editar.getDni());
			c.setTelefono(editar.getTelefono());
			c.setDireccion(editar.getDireccion());
			c.setDescuento(editar.getDescuento());
			Ruta ruta= rutaRepositorio.findById(editar.getRuta()).orElse(null);
			c.setRuta(ruta);
			
			return clienteRepositorio.save(c);
		}).orElseThrow(() -> new ClienteNotFoundException(id));
	}

	/**
	 * Borra un cliente del catálogo en base a su id
	 * 
	 * @param id
	 * @return Código 204 sin contenido
	 */
	@DeleteMapping("/cliente/{id}")
	public ResponseEntity<?> borrarCliente(@PathVariable Long id) {
		Cliente cliente = clienteRepositorio.findById(id)
				.orElseThrow(() -> new ClienteNotFoundException(id));
		
		clienteRepositorio.delete(cliente);
		return ResponseEntity.noContent().build();
	}
	

}
