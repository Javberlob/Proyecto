package rest.controller;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Example;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import rest.dto.ComercialDTO;
import rest.dto.CreateComercialDTO;
import rest.dto.FacturaDTO;
import rest.dto.converter.ComercialDTOConverter;
import rest.dto.converter.FacturaDTOConverter;
import rest.error.ComercialNotFoundException;
import rest.modelo.Comercial;
import rest.modelo.ComercialRepositorio;
import rest.modelo.Factura;
import rest.modelo.FacturaRepositorio;
import rest.modelo.Inicio;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class ComercialController {

	private final ComercialRepositorio comercialRepositorio;
	private final FacturaRepositorio facturaRepositorio;
	
	private final ComercialDTOConverter comercialDTOConverter;
	private final FacturaDTOConverter facturaDTOConverter;

	/**
	 * Obtenemos todos los comercials
	 * 
	 * @return 404 si no hay comercials, 200 y lista de comercials si hay uno o más
	 */
	@GetMapping("/comercial")
	public ResponseEntity<?> obtenerTodos() {
		List<Comercial> result = comercialRepositorio.findAll();

		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		} else {

			List<ComercialDTO> dtoList = result.stream().map(comercialDTOConverter::convertToDto)
					.collect(Collectors.toList());

			return ResponseEntity.ok(dtoList);
		}

	}
	

	/**
	 * Obtenemos un comercial en base a su ID
	 * 
	 * @param id
	 * @return 404 si no encuentra el comercial, 200 y el comercial si lo encuentra
	 */
	@GetMapping("/comercial/{id}")
	public ComercialDTO obtenerUno(@PathVariable Long id) {
		ComercialDTO comercialDTO = comercialDTOConverter.convertToDto(comercialRepositorio.findById(id)
				.orElseThrow(() -> new ComercialNotFoundException(id)));
		return comercialDTO;
	}
	
	/**
	 * Obtenemos las facturas de un comercial
	 * 
	 * @param id
	 * @return 404 si no encuentra el comercial, 200 y el comercial si lo encuentra
	 */
	@GetMapping("/comercial/{id}/facturas")
	public ResponseEntity<?> obtenerFacturasComercial(@PathVariable Long id) {
		Factura fEx = new Factura();
		fEx.setComercial(comercialRepositorio.findById(id).orElseThrow(() -> new ComercialNotFoundException(id)));
		Example<Factura> example = Example.of(fEx);
		List<Factura> facturas = facturaRepositorio.findAll(example);
		
		List<FacturaDTO> dtoList = facturas.stream().map(facturaDTOConverter::convertToDto)
				.collect(Collectors.toList());

		return ResponseEntity.ok(dtoList);
	}
	
	
	/**
	 * Confirmamos los credenciales de un comercial
	 * 
	 * 
	 * @return 404 si no encuentra el comercial, 200 y el comercial si lo encuentra
	 */
	@GetMapping("/comercial/inicio")
	public ResponseEntity<?> comprobarPass(@RequestBody Inicio inicio){
		Comercial comercial= new Comercial();
		comercial.setDni(inicio.getDni());
		comercial.setPassword(inicio.getPassword());
		Example<Comercial> example = Example.of(comercial);
		Comercial respuesta= comercialRepositorio.findOne(example).orElseThrow(() -> new ComercialNotFoundException(comercial.getDni()));
		
		return ResponseEntity.ok(respuesta);
	}

	/**
	 * Insertamos un nuevo comercial
	 * 
	 * @param nuevo
	 * @return 201 y el comercial insertado
	 */
	@PostMapping("/comercial")
	public ResponseEntity<?> nuevoComercial(@RequestBody CreateComercialDTO nuevo) {

		Comercial nuevoComercial = new Comercial();
		nuevoComercial.setNombre(nuevo.getNombre());
		nuevoComercial.setDni(nuevo.getDni());
		nuevoComercial.setTelefono(nuevo.getTelefono());
		MessageDigest digest;
		try {
			
			digest = MessageDigest.getInstance("SHA-256");
		
			byte[] pass = digest.digest(nuevo.getPassword().getBytes(StandardCharsets.UTF_8));
			nuevoComercial.setPassword(pass.toString());
			
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return ResponseEntity.status(HttpStatus.CREATED).body(comercialRepositorio.save(nuevoComercial));
	}

	/**
	 * 
	 * @param editar
	 * @param id
	 * @return 200 Ok si la edición tiene éxito, 404 si no se encuentra el comercial
	 */
	@PutMapping("/comercial/{id}")
	public Comercial editarComercial(@RequestBody Comercial editar, @PathVariable Long id) {

		return comercialRepositorio.findById(id).map(c -> {
			c.setNombre(editar.getNombre());
			c.setDni(editar.getDni());
			c.setTelefono(editar.getTelefono());
		
			return comercialRepositorio.save(c);
		}).orElseThrow(() -> new ComercialNotFoundException(id));
	}

	/**
	 * Borra un comercial del catálogo en base a su id
	 * 
	 * @param id
	 * @return Código 204 sin contenido
	 */
	@DeleteMapping("/comercial/{id}")
	public ResponseEntity<?> borrarComercial(@PathVariable Long id) {
		Comercial comercial = comercialRepositorio.findById(id)
				.orElseThrow(() -> new ComercialNotFoundException(id));
		
		comercialRepositorio.delete(comercial);
		return ResponseEntity.noContent().build();
	}
	

}
