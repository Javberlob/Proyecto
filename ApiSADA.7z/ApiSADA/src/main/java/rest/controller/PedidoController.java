package rest.controller;

import java.util.List;
import java.util.stream.Collectors;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import rest.dto.PedidoDTO;
import rest.dto.CreatePedidoDTO;
import rest.dto.converter.PedidoDTOConverter;
import rest.error.PedidoNotFoundException;
import rest.modelo.Factura;
import rest.modelo.FacturaRepositorio;
import rest.modelo.Pedido;
import rest.modelo.PedidoRepositorio;
import rest.modelo.Producto;
import rest.modelo.ProductoRepositorio;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class PedidoController {

	private final PedidoRepositorio pedidoRepositorio;
	private final FacturaRepositorio facturaRepositorio;
	private final ProductoRepositorio productoRepositorio;
	
	private final PedidoDTOConverter pedidoDTOConverter;
	
	

	/**
	 * Obtenemos todos los pedidos
	 * 
	 * @return 404 si no hay pedidos, 200 y lista de pedidos si hay uno o más
	 */
	@GetMapping("/pedido")
	public ResponseEntity<?> obtenerTodos() {
		List<Pedido> result = pedidoRepositorio.findAll();

		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		} else {

			List<PedidoDTO> dtoList = result.stream().map(pedidoDTOConverter::convertToDto)
					.collect(Collectors.toList());

			return ResponseEntity.ok(dtoList);
		}

	}

	/**
	 * Obtenemos un pedido en base a su ID
	 * 
	 * @param id
	 * @return 404 si no encuentra el pedido, 200 y el pedido si lo encuentra
	 */
	@GetMapping("/pedido/{id}")
	public PedidoDTO obtenerUno(@PathVariable Long id) {
		

		PedidoDTO pedidoDTO = pedidoDTOConverter.convertToDto(pedidoRepositorio.findById(id)
				.orElseThrow(() -> new PedidoNotFoundException(id)));
		return pedidoDTO;
	}

	/**
	 * Insertamos un nuevo pedido
	 * 
	 * @param nuevo
	 * @return 201 y el pedido insertado
	 */
	@PostMapping("/pedido")
	public ResponseEntity<?> nuevoPedido(@RequestBody CreatePedidoDTO nuevo) {

			Pedido nuevoPedido = new Pedido();
			Factura factura= facturaRepositorio.findById(nuevo.getFactura()).orElse(null);
			nuevoPedido.setFactura(factura);
			Producto producto= productoRepositorio.findById(nuevo.getProducto()).orElse(null);
			nuevoPedido.setProducto(producto);
			nuevoPedido.setCantidad(nuevo.getCantidad());
			nuevoPedido.setPrecio((nuevo.getCantidad()*producto.getPrecio())*(1-(factura.getCliente().getDescuento()/100.0F)));
			pedidoRepositorio.save(nuevoPedido);
			
			
			//Se suma a la factura correspondiente el precio del pedido asociado.
			factura.setPrecio(factura.getPrecio()+(nuevoPedido.getPrecio()));
			facturaRepositorio.save(factura);
			
			PedidoDTO pedidoDTO = pedidoDTOConverter .convertToDto(nuevoPedido);
			return ResponseEntity.status(HttpStatus.CREATED).body(pedidoDTO);
	}

	/**
	 * 
	 * @param editar
	 * @param id
	 * @return 200 Ok si la edición tiene éxito, 404 si no se encuentra el pedido
	 */
	@PutMapping("/pedido/{id}")
	public Pedido editarPedido(@RequestBody Pedido editar, @PathVariable Long id) {

		return pedidoRepositorio.findById(id).map(c -> {
			c.setCantidad(editar.getCantidad());
			
		
			return pedidoRepositorio.save(c);
		}).orElseThrow(() -> new PedidoNotFoundException(id));
	}

	/**
	 * Borra un pedido del catálogo en base a su id
	 * 
	 * @param id
	 * @return Código 204 sin contenido
	 */
	@DeleteMapping("/pedido/{id}")
	public ResponseEntity<?> borrarPedido(@PathVariable Long id) {
		
		Pedido pedido = pedidoRepositorio.findById(id)
				.orElseThrow(() -> new PedidoNotFoundException(id));
		
		Factura factura= facturaRepositorio.findById(pedido.getFactura().getId_factura()).orElse(null);
		
		factura.setPrecio(factura.getPrecio()-(pedido.getPrecio()));
		facturaRepositorio.save(factura);
		
		pedidoRepositorio.delete(pedido);
		return ResponseEntity.noContent().build();
	}
	

}
