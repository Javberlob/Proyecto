package rest.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import rest.dto.FacturaDTO;
import rest.dto.CreateFacturaDTO;
import rest.dto.converter.FacturaDTOConverter;
import rest.error.FacturaNotFoundException;
import rest.modelo.Cliente;
import rest.modelo.ClienteRepositorio;
import rest.modelo.Comercial;
import rest.modelo.ComercialRepositorio;
import rest.modelo.Factura;
import rest.modelo.FacturaRepositorio;


import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class FacturaController {

	private final FacturaRepositorio facturaRepositorio;
	private final ClienteRepositorio clienteRepositorio;
	private final ComercialRepositorio comercialRepositorio;
	
	private final FacturaDTOConverter facturaDTOConverter;
	

	/**
	 * Obtenemos todos los facturas
	 * 
	 * @return 404 si no hay facturas, 200 y lista de facturas si hay uno o más
	 */
	@GetMapping("/factura")
	public ResponseEntity<?> obtenerTodos() {
		List<Factura> result = facturaRepositorio.findAll();

		if (result.isEmpty()) {
			return ResponseEntity.notFound().build();
		} else {

			List<FacturaDTO> dtoList = result.stream().map(facturaDTOConverter::convertToDto)
					.collect(Collectors.toList());

			return ResponseEntity.ok(dtoList);
		}

	}

	/**
	 * Obtenemos un factura en base a su ID
	 * 
	 * @param id
	 * @return 404 si no encuentra el factura, 200 y el factura si lo encuentra
	 */
	@GetMapping("/factura/{id}")
	public FacturaDTO obtenerUno(@PathVariable Long id) {
		FacturaDTO facturaDTO = facturaDTOConverter.convertToDto(facturaRepositorio.findById(id)
				.orElseThrow(() -> new FacturaNotFoundException(id)));
		return facturaDTO;
	}

	/**
	 * Insertamos un nuevo factura
	 * 
	 * @param nuevo
	 * @return 201 y el factura insertado
	 */
	@PostMapping("/factura")
	public ResponseEntity<?> nuevoFactura(@RequestBody CreateFacturaDTO nuevo) {

			Factura nuevaFactura = new Factura();
			Cliente cliente= clienteRepositorio.findById(nuevo.getCliente()).orElse(null);
			nuevaFactura.setCliente(cliente);
			Comercial comercial= comercialRepositorio.findById(nuevo.getComercial()).orElse(null);
			nuevaFactura.setComercial(comercial);
			nuevaFactura.setFecha(LocalDateTime.now());
			nuevaFactura.setPagado(nuevo.isPagado());
			facturaRepositorio.save(nuevaFactura);
			
			FacturaDTO facturaDTO = facturaDTOConverter .convertToDto(nuevaFactura);
			return ResponseEntity.status(HttpStatus.CREATED).body(facturaDTO);
	}

	/**
	 * 
	 * @param editar
	 * @param id
	 * @return 200 Ok si la edición tiene éxito, 404 si no se encuentra el factura
	 */
	@PutMapping("/factura/{id}")
	public Factura editarFactura(@RequestBody Factura editar, @PathVariable Long id) {

		return facturaRepositorio.findById(id).map(c -> {
			c.setPagado(editar.isPagado());
		
			return facturaRepositorio.save(c);
		}).orElseThrow(() -> new FacturaNotFoundException(id));
	}

	/**
	 * Borra un factura del catálogo en base a su id
	 * 
	 * @param id
	 * @return Código 204 sin contenido
	 */
	@DeleteMapping("/factura/{id}")
	public ResponseEntity<?> borrarFactura(@PathVariable Long id) {
		Factura factura = facturaRepositorio.findById(id)
				.orElseThrow(() -> new FacturaNotFoundException(id));
		
		facturaRepositorio.delete(factura);
		return ResponseEntity.noContent().build();
	}
	

}
