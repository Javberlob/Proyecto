package rest.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name="clientes")
public class Cliente {

	@Id @GeneratedValue
	private Long id_cliente;
	
	private String nombre;
	
	private String dni;

	private String telefono;
	
	private String direccion;
	
	@OneToOne
	@JoinColumn(name="ruta")
	private Ruta ruta;
	
	private int descuento;
	
}
