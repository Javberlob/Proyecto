package rest.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name="comerciales")
public class Comercial {

	@Id @GeneratedValue
	private Long id_comercial;
	
	private String nombre;
	
	private String dni;

	private String telefono;
	
	private String password;
	
	
	
}
