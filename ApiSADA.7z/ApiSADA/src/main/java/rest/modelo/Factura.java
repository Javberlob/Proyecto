package rest.modelo;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name="facturas")
public class Factura {

	@Id @GeneratedValue
	private Long id_factura;
	
	@OneToOne
	@JoinColumn(name="cliente")
	private Cliente cliente;
	
	@OneToOne
	@JoinColumn(name="comercial")
	private Comercial comercial;

	private LocalDateTime fecha;
	
	
	private boolean pagado;
	
	private float precio;
	
	
	
}
