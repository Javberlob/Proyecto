package rest.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name="pedidos")
public class Pedido {

	@Id @GeneratedValue
	private Long id_pedido;
	
	@OneToOne
	@JoinColumn(name="facturas")
	private Factura factura;
	
	@OneToOne
	@JoinColumn(name="productos")
	private Producto producto;
	
	private int cantidad;
	
	private float precio;
	
	
	
}
