package rest.modelo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RutaRepositorio extends JpaRepository<Ruta, Long> {

}
