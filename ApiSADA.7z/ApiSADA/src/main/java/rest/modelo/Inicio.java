package rest.modelo;




import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor


public class Inicio {
	
	
	private String dni;

	private String password;
	
}
